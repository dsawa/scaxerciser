## Projekt do pracy magisterskiej 
##### Szablon projektów dla zadań Scaxercisera.

Praca magisterska [master-thesis](https://github.com/dsawa/master-thesis)

Aplikacja zarządzająca zadaniami: [Scaxercsier](https://github.com/dsawa/scaxerciser)

Aplikacja analizująca rozwiązania: [Scaxerciser_analyze](https://github.com/dsawa/scaxerciser_analyze)

* Komunikacja projektu ze Scaxerciserem:
  + Polecenie SBT wysyłające rozwiązanie: `sendSolution loginUzytkownika haslo`
  + Adres API Scaxercisera podany w project/ScaxerciserClient.scala

------------
Standardowa konfiguracja:

     Scala 2.11.1
     SBT 0.13.5
     ScalaTest 2.1.6
     ScalaCheck 1.11.4
     IntelliJ IDEA 
     Scala-IDE 3.0+

Wymagania:
---------------
* SBT w wersji 0.13.5
* [sbt 0.13.5](https://scala-sbt.org)

IDE
---------------
* Preferowane narzędzia deweloperskie
	* [Intellij IDEA 13](http://jetbrains.com/download)  (z wtyczkami Scala i SBT)
	* [Scala IDE 3](http://scala-ide.org/download/). (z conajmniej wtyczką obsługującą Scalatest)
* Więcej szczegółów [sbt eclipse](https://github.com/typesafehub/sbteclipse/wiki/Using-sbteclipse).

Konfiguracja projektu dla danego IDE
-----------------
	> gen-idea
 	> eclipse

Testowanie
------------------
Uruchomienie testów

	> test

Testowanie pojedyńczej klasy

	> testOnly package.subpackage.Class


Dodatkowe komendy
-----------------
Uruchamia scala REPL ze wszystkimi dostępnymi zależnościami projektu.

	> console
	> run

Code Coverage
------------------
Jacoco via [Jacoco4sbt](https://github.com/sbt/jacoco4sbt/wiki)

	> jacoco:check

Zalecane zapoznanie się z dokumentacją.

SBT Launch - przydatne opcje konfiguracji
---------------------------------------
Konfiguracja w ~/.sbt/conf/sbtconfig.txt lub sbtopts

	# Pamięć w SBT JVM
 
	-Xms256M
 
	-Xmx2048M
 
	-XX:MaxPermSize=256m
 
	-XX:ReservedCodeCacheSize=128m
 
	# Dodatkowe opcje SBT i HTTP Proxy jeśli potrzebne
 
	# -Dsbt.ivy.home=<m2 repo>
 
	-Dsbt.log.format=true
 
	# -Dhttp.proxyHost=<your_proxy_host>
 
	# -Dhttp.proxyPort=<your_proxy_port>
 
	# -Dhttp.nonProxyHosts="<dont_use_proxy_for_these_addresses>"


Na podstawie szablonu Fernanda Racca
--------------------
Fernando Racca

[@quant_leap](http://twitter.com/quant_leap)

[fractal/skeleton](http://github.com/fractal/skeleton)
