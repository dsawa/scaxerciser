Szablon projektu
------------

Standardowa konfiguracja:

     Scala 2.10.3
     SBT 0.13.1
     ScalaTest 2.0
     ScalaCheck 1.11.2
     IntelliJ IDEA 
     Scala-IDE 3.0+

Wymagania:
---------------
* SBT w wersji 0.13.1
* [sbt 0.13.1](https://scala-sbt.org)

IDE
---------------
* Preferowane narzędzia deweloperskie
	* [Intellij IDEA 13](http://jetbrains.com/download)  (z wtyczkami Scala i SBT)
	* [Scala IDE 3](http://scala-ide.org/download/). (z conajmniej wtyczką obsługującą Scalatest)
* Więcej szczegółów [sbt eclipse](https://github.com/typesafehub/sbteclipse/wiki/Using-sbteclipse).

Konfiguracja projektu dla danego IDE
-----------------
	> gen-idea
 	> eclipse

Testowanie
------------------
Incremental compilation (przyrostowa kompilacja)

	> ~ test

Testowanie pojedyńczej klasy

	> testOnly package.subpackage.Class

Testy Integracji
-------------------

	> it:test

Dodatkowe komendy
-----------------
Uruchamia scala REPL ze wszystkimi dostępnymi zależnościami projektu.
	> console
	> run

Code Coverage
------------------
Jacoco via [Jacoco4sbt](https://github.com/sbt/jacoco4sbt/wiki)

	> jacoco:check

Zalecane zapoznanie się z dokumentacją, szczególnie w przypadku testów integracji.

Styl 
-------------------
ScalaStyle(http://www.scalastlye.org)

	> scalastyle

Statystyka kodu
---------------------

	> sbt-stats

SBT Launch - przydatne opcje konfiguracji
---------------------------------------
Konfiguracja w ~/.sbt/conf/sbtconfig.txt lub sbtopts

	# Pamięć w SBT JVM
 
	-Xms256M
 
	-Xmx2048M
 
	-XX:MaxPermSize=256m
 
	-XX:ReservedCodeCacheSize=128m
 
	# Dodatkowe opcje SBT i HTTP Proxy jeśli potrzebne
 
	# -Dsbt.ivy.home=<m2 repo>
 
	-Dsbt.log.format=true
 
	# -Dhttp.proxyHost=<your_proxy_host>
 
	# -Dhttp.proxyPort=<your_proxy_port>
 
	# -Dhttp.nonProxyHosts="<dont_use_proxy_for_these_addresses>"


Na podstawie szablonu Fernanda Racca
--------------------
Fernando Racca

[@quant_leap](http://twitter.com/quant_leap)

[fractal/skeleton](http://github.com/fractal/skeleton)
