import sbt._
import Keys._

/**
 * Additional configuration
 */
object Build extends Build {

  lazy override val projects = Seq(assignmentProject)
  lazy val assignmentProject = Project("assignment", file("."))
    .configs(IntegrationTest)
    .settings(Defaults.itSettings: _*)
    .settings(scalaSource in IntegrationTest <<= baseDirectory / "src/test/scala")
    .settings(resourceDirectory in IntegrationTest <<= baseDirectory / "src/test/resources")
    .settings(parallelExecution in IntegrationTest := false)
    .settings(testOptions in IntegrationTest += Tests.Argument(TestFrameworks.ScalaTest, "-n", "org.scalatest.tags.Slow"))
    .settings(commands ++= Seq(sendSolution))

  lazy val assignmentId = settingKey[String]("Returns assignment Id.")
  lazy val packageFilesToSubmit = taskKey[java.io.File]("Prepares needed files for Scaxerciser")

  def sendSolution = Command.args("sendSolution", "<userData>") {
    (state, args) =>
      if (args.size != 2) {
        state.log.error("Required two arguments. (<email>,<password>)")
        state.fail
      } else {
        val extracted: Extracted = Project.extract(state)
        val assignmentIdOpt = extracted.getOpt(assignmentId)

        if (assignmentIdOpt.isDefined) {
          val userEmail = args.head
          val userPassword = args.last

          extracted.runTask(packageFilesToSubmit, state)
          val file = getPackagedFile(extracted)

          ScaxerciserClient.sendSolution(assignmentIdOpt.get, userEmail, userPassword, file)
          state
        } else {
          state.log.error("Setting assignmentId is not defined.")
          state.fail
        }
      }
  }

  private def getPackagedFile(extractedProject: Extracted): java.io.File = {
    val scalaVer: String = extractedProject.getOpt(scalaVersion).get
    val scalaVerInDir: String = ("""\d+\.\d+""".r findFirstIn scalaVer).get
    val projectVer: String = extractedProject.getOpt(version).get
    val projectName: String = extractedProject.getOpt(name).get

    val filePath = extractedProject.get(target) + "/scala-" + scalaVerInDir + "/" +
      projectName + "_" + scalaVerInDir + "-" + projectVer + "-sources.jar"

    new java.io.File(filePath)
  }

}
