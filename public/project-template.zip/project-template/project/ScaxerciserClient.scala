import scalaj.http.{Http, HttpOptions, MultiPart}
import java.io.{File, FileInputStream}

object ScaxerciserClient extends ScaxerciserConnection {

  val connTimeout = 10 * 1000
  val readTimeout = 15 * 1000
  val url = "http://localhost:9000/api"

  def sendSolution(assignmentId: String, userEmail: String, userPassword: String, solutionFile: File) = {
    try {
      val requestUrl = url + "/assignments/" + assignmentId + "/solutions/submit"

      val multiPart = MultiPart("solutionFile", solutionFile.getName, "application/java-archive",
        new FileInputStream(solutionFile), solutionFile.length(), len => {
          println("[info] " + (len.toDouble/solutionFile.length() * 100).round + "%")
      })

      val http = Http.multipart(requestUrl, multiPart)
        .option(HttpOptions.connTimeout(connTimeout))
        .option(HttpOptions.readTimeout(readTimeout))
        .option(HttpOptions.allowUnsafeSSL)
        .params("assignmentId" -> assignmentId)
        .auth(userEmail, userPassword)

      println("[info] Sending..")
      val response = http.sendBufferSize(1024).asString
      println("[info] Done!")
      println("[log] " + response)
    } catch {
      case ex: Exception => println(ex.getMessage + " | " + ex.getCause)
    }
  }

}
