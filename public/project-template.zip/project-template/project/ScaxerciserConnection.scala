trait ScaxerciserConnection {
  val connTimeout: Int
  val readTimeout: Int
  val url: String
}